import Link from "next/link";

const NAV_LINKS = [
  { label: "Accueil", href: "/" },
  { label: "Diagnostic de niveau", href: "/diagnostic" },
  { label: "Français", href: "/francais" },
  { label: "Progression", href: "/progression" },
];

const RESOURCE_LINKS = [
  { label: "Grammaire & orthographe", href: "/francais" },
  { label: "Analyse & didactique", href: "/francais/analyse-de-la-langue" },
  { label: "Révisions ciblées", href: "/revisions-ciblees" },
  { label: "Glossaire", href: "/ressources/glossaire" },
  { label: "Voir l'offre", href: "/offre" },
];

const LEGAL_LINKS = [
  { label: "Conditions générales", href: "/cgu" },
  { label: "Politique de confidentialité", href: "/politique-confidentialite" },
  { label: "Mentions légales", href: "/mentions-legales" },
  { label: "Contact", href: "mailto:contact@crpe-prep.fr" },
];

export function SiteFooter() {
  return (
    <footer className="border-t border-border bg-secondary">
      {/* Main grid */}
      <div className="mx-auto max-w-6xl px-6 py-14 lg:py-16">
        <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-[1.6fr_1fr_1fr_1fr]">
          {/* About */}
          <div>
            <p className="font-serif text-xl font-semibold text-ink">CRPE Prep</p>
            <p className="mt-3 max-w-xs text-sm leading-7 text-muted">
              Un espace de révision structuré pour préparer le CRPE avec des séries courtes,
              des corrections lisibles et une progression par domaine.
            </p>
            <div className="mt-6 flex gap-2.5">
              <SocialIcon label="X / Twitter" href="#">
                <XIcon />
              </SocialIcon>
              <SocialIcon label="LinkedIn" href="#">
                <LinkedInIcon />
              </SocialIcon>
              <SocialIcon label="Instagram" href="#">
                <InstagramIcon />
              </SocialIcon>
            </div>
          </div>

          {/* Navigation */}
          <FooterColumn title="Navigation" links={NAV_LINKS} />

          {/* Ressources */}
          <FooterColumn title="Ressources" links={RESOURCE_LINKS} />

          {/* Légal */}
          <FooterColumn title="Légal" links={LEGAL_LINKS} />
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-border">
        <div className="mx-auto flex max-w-6xl flex-col gap-3 px-6 py-5 sm:flex-row sm:items-center sm:justify-between">
          <p className="text-xs text-muted">© 2026 CRPE Prep — Tous droits réservés</p>
          <p className="text-xs text-muted">
            Conforme programme CRPE 2026 · Exercices ajoutés régulièrement
          </p>
        </div>
      </div>
    </footer>
  );
}

function FooterColumn({
  title,
  links,
}: {
  title: string;
  links: { label: string; href: string }[];
}) {
  return (
    <div>
      <p className="text-xs font-semibold uppercase tracking-[0.16em] text-ink">{title}</p>
      <ul className="mt-5 space-y-3">
        {links.map(({ label, href }) => (
          <li key={label}>
            <Link
              href={href}
              className="text-sm text-muted transition-colors hover:text-ink"
            >
              {label}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}

function SocialIcon({
  label,
  href,
  children,
}: {
  label: string;
  href: string;
  children: React.ReactNode;
}) {
  return (
    <a
      href={href}
      aria-label={label}
      className="flex h-9 w-9 items-center justify-center rounded-full border border-border bg-card text-muted transition-colors hover:border-accent hover:bg-accent hover:text-paper"
    >
      {children}
    </a>
  );
}

function XIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-4 w-4" fill="currentColor" aria-hidden="true">
      <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-4.714-6.231-5.401 6.231H2.747l7.73-8.835L1.254 2.25H8.08l4.253 5.622L18.244 2.25zm-1.161 17.52h1.833L7.084 4.126H5.117L17.083 19.77z" />
    </svg>
  );
}

function LinkedInIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-4 w-4" fill="currentColor" aria-hidden="true">
      <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 0 1-2.063-2.065 2.064 2.064 0 1 1 2.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
    </svg>
  );
}

function InstagramIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-4 w-4" fill="currentColor" aria-hidden="true">
      <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 1 0 0 12.324 6.162 6.162 0 0 0 0-12.324zM12 16a4 4 0 1 1 0-8 4 4 0 0 1 0 8zm6.406-11.845a1.44 1.44 0 1 0 0 2.881 1.44 1.44 0 0 0 0-2.881z" />
    </svg>
  );
}
